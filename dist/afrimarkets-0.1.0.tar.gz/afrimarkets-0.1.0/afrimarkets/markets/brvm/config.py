from ..african_market import AfricanMarket

import requests
from bs4 import BeautifulSoup
import pandas as pd


class BRVM(AfricanMarket):
    """
    Bourse Régionale des Valeurs Mobilières.
    """

    code = "BRVM"

    def __init__(self):
        super().__init__(
            name="Bourse Régionale des Valeurs Mobilières",
            code=self.code,
            country="Ivory Coast",
            currency="XOF",
            description=(
                "Regional stock exchange serving "
                "the West African Economic and Monetary Union."
            ),
        )

    def get_tickers(self, *args, **kwargs):
        """
        Return BRVM listed securities.

        This method contains BRVM-specific logic.
        """
        tick_data = self.__get_tickers__()

        self.indexes = [asset["Symbol"] for asset in tick_data if asset["Type"] == "Index"]
        self.shares = [asset["Symbol"] for asset in tick_data if asset["Type"] == "Share"]
        self.bonds = [asset["Symbol"] for asset in tick_data if asset["Type"] == "Bond"]
        self.index_table = [asset for asset in tick_data if asset["Type"] == "Index"]
        self.share_table = [asset for asset in tick_data if asset["Type"] == "Share"]
        self.bond_table = [asset for asset in tick_data if asset["Type"] == "Bond"]



    def get_data(
        self,
        tickers=None,
        start=None,
        end=None,
        freq="1d",
        format="dataframe",
    ):
        """
        Return historical BRVM data.

        This method contains BRVM-specific logic.
        """

        # TODO:
        # BRVM-specific data provider

        raise NotImplementedError(
            "BRVM.get_data() is not implemented yet."
        )


    def __get_tickers__(self):

        """
        Return BRVM listed securities.
        This method contains BRVM-specific logic.
        """

        url = "https://www.sikafinance.com"
        headers = {
            "User-Agent": "Mozilla/5.0"
        }

        response = requests.get(url,headers=headers,timeout=30)

        if response.status_code == 200:

            soup = BeautifulSoup(response.text, "html.parser")
            select = soup.find("select", id="dpShares")

            assets = []
            for option in select.find_all("option"):

                code = option.get("value")
                if code:
                    assets.append({
                        "Type"  : "Share" if "." in code else "Index",
                        "Symbol": code.split(".")[0],
                        "Ticker": code,
                        "Country": code.split(".")[1] if "." in code else "",
                        "Name": option.get_text(" ", strip=True)
                    })

            # assets_sorted = sorted(assets, key=lambda x: x["Symbol"].upper())
            assets.sort(key=lambda x: x["Symbol"].upper())
            # df = pd.DataFrame(assets)
        return assets