from typing import Type, Dict
from inspect import isabstract


class MarketRegistry:
    """
    Registry containing all available financial markets.
    """

    _markets: Dict[str, Type] = {}

    @classmethod
    def register(cls, market_class):

        if isabstract(market_class):
            return

        code = getattr(market_class, "code", None)

        if not code:
            return

        cls._markets[code] = market_class


    @classmethod
    def get(cls, code: str):
        """
        Return a market instance from its code.
        """

        code = code.strip().upper()

        if code not in cls._markets:
            raise KeyError(
                f"Unknown market: '{code}'. "
                f"Available markets: {cls.codes()}"
            )

        market_class = cls._markets[code]

        return market_class()

    @classmethod
    def get_class(cls, code: str):
        """
        Return the market class itself.
        """

        code = code.strip().upper()

        if code not in cls._markets:
            raise KeyError(
                f"Unknown market: '{code}'."
            )

        return cls._markets[code]

    @classmethod
    def codes(cls) -> list[str]:
        """
        Return all registered market codes.
        """

        return sorted(cls._markets.keys())

    @classmethod
    def markets(cls) -> dict:
        """
        Return all registered markets.
        """

        return cls._markets.copy()

    @classmethod
    def clear(cls) -> None:
        """
        Clear the registry.

        Mainly useful for testing.
        """

        cls._markets.clear()


def get_market(code: str):
    """
    Shortcut for MarketRegistry.get().
    """

    return MarketRegistry.get(code)


def get_market_class(code: str):
    """
    Shortcut for MarketRegistry.get_class().
    """

    return MarketRegistry.get_class(code)


def available_markets() -> list[str]:
    """
    Return all available market codes.
    """

    return MarketRegistry.codes()